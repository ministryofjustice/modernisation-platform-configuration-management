-- Run as oms_owner or sysdba
SPOOL nomis_api_install.log
--
PROMPT drop schemas if they already exist
--
@@DDL/DROP_SCHEMAS.sql
--
PROMPT Create owner and user schemas
--
@@DDL/CREATE_SCHEMAS.sql
--
PROMPT grant permissions to api_owner schema
--
@@DDL/API_OWNER_GRANTS.sql
--
PROMPT create api_owner packages
--
@@Packages/CORE_UTILS.pkg
@@Packages/API_CORE_PROCS.pkg
@@Packages/API_VISIT_PROCS.pkg
--
PROMPT create synonyms for api_owner packages
--
@@DDL/API_OWNER_SYNONYMS.sql
--
PROMPT grant execute permissions on packages to api_user schema
--
@@DDL/API_USER_GRANTS.sql
spool off
