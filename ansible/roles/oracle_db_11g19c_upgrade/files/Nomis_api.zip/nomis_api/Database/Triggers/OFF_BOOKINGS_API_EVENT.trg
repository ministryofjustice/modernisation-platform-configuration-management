create or replace trigger oms_owner.off_bookings_api_event
after insert or update of offender_id, living_unit_id, agy_loc_id
on oms_owner.offender_bookings
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:  off_bookings_api_events
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.2        24/01/2017    Kumar            Removed SOI related code   
   1.2        24/01/2017    Kumar            Merged PSS and SOI related code   
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        10/11/2016    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);

begin
   -- This trigger is required to fire during merge
   if updating then
      if api_owner.core_utils.is_digital_prison(:new.agy_loc_id) then
         --
         -- Send transaction message to unilink
         api_owner.pss_events.offender_update(p_offender_book_id => :old.offender_book_id,
                                      p_offender_id      => :old.offender_id,
                                      p_agy_loc_id       => :new.agy_loc_id,
                                      p_new_offender_id  => case 
                                                            when :new.offender_id != :old.offender_id 
                                                            then :new.offender_id 
                                                            else null end,
                                      p_living_unit_id   => case
                                                            when nvl(:new.living_unit_id, -1) != nvl(:old.living_unit_id, -1) 
                                                            then :new.living_unit_id
                                                            else null end);
      end if;
   end if;
   
exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_BOOKINGS_API_EVENT',
                                    p_message    => 'Error Updating booking for offender_book_id '||
                                                    :old.offender_book_id||':'||sqlerrm);
end;
/
show err
