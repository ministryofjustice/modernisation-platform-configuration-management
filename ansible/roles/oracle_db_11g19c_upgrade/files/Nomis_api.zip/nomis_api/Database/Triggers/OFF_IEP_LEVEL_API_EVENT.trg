create or replace trigger oms_owner.off_iep_level_api_event
after insert 
on oms_owner.offender_iep_levels
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:  off_iep_level_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);
begin
   -- This trigger is required to fire during merge

   if api_owner.core_utils.is_digital_prison(:new.agy_loc_id) then
      --
      -- Send transaction message to unilink
      api_owner.pss_events.offender_update(
                                   p_offender_book_id => :new.offender_book_id,
                                   p_iep_level        => :new.iep_level,
                                   p_iep_level_desc   => oms_miscellaneous.getdesccode('IEP_LEVEL',:new.iep_level));

   end if;

exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_IEP_LEVEL_API_EVENT',
                                    p_message    => 'Error Inserting iep level '||:new.iep_level_seq||
                                                    ' for offender_book_id '||:new.offender_book_id||
                                                    ':'||sqlerrm);
end;
/
show err
