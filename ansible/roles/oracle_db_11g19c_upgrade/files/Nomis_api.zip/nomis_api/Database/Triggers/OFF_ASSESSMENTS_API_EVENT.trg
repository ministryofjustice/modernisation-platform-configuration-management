create or replace trigger oms_owner.off_assessments_api_event
after update of evaluation_result_code 
on oms_owner.offender_assessments
referencing new as new old as old
for each row
when (new.evaluation_result_code = 'APP')
declare
/******************************************************************************
   Name:  off_assessments_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/
   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);
   function is_category_assessment(p_assessment_id in assessments.assessment_id%type) return boolean
   is
      v_dummy varchar2(1);
   begin
      select 'Y'
        into v_dummy
        from assessments
       where assessment_id = p_assessment_id
         and caseload_type = 'INST'
         and determine_sup_level_flag = 'Y';
      return true;
   exception
      when no_data_found then
         return false;
   end is_category_assessment;
        
begin
   -- This trigger is required to fire during merge

   if api_owner.core_utils.is_in_digital_prison(:new.offender_book_id) then

      if nvl(:old.evaluation_result_code,'XYZ') != nvl(:new.evaluation_result_code,'XYZ') then

         if is_category_assessment(:new.assessment_type_id) then
            --
            -- Send transaction message to unilink
            api_owner.pss_events.offender_update(
                  p_offender_book_id => :new.offender_book_id,
                  p_sec_category     => :new.review_sup_level_type,
                  p_sec_category_desc => oms_miscellaneous.getdesccode('SUP_LVL_TYPE',
                                                                       :new.review_sup_level_type));
         end if;
      end if;

   end if;

exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_ASSESSMENTS_API_EVENT',
                                    p_message    => 'Error updating assessment '||:new.assessment_seq||
                                                    ' for offender_book_id '||:new.offender_book_id||':'||
                                                    sqlerrm);
end;
/
show err
