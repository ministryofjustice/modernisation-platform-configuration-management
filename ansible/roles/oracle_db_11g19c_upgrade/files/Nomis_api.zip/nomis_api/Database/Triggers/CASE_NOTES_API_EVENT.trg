create or replace trigger oms_owner.case_notes_api_event
after insert or update of case_note_text, amendment_flag
on oms_owner.offender_case_notes
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:  case_notes_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.0        07/04/2017    Paul Morris      Initial version
******************************************************************************/
   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);

   v_offender_book_id offender_bookings.offender_book_id%type;
   v_root_offender_id offender_bookings.root_offender_id%type;
   v_agy_loc_id offender_bookings.agy_loc_id%type;

begin
   -- TODO Is this trigger required to fire during merge ?

   --
   -- Create row in api_offender_events table
   --
   if inserting  or updating then
      api_owner.api_events.case_note( p_offender_book_id        => :new.offender_book_id,
                                      p_case_note_id            => :new.case_note_id,
                                      p_contact_date            => :new.contact_date,
                                      p_contact_time            => :new.contact_time,
                                      p_case_note_type          => :new.case_note_type,
                                      p_case_note_type_desc     => oms_miscellaneous.getdesccode('TASK_TYPE', :new.case_note_type),
                                      p_case_note_sub_type      => :new.case_note_sub_type,
                                      p_case_note_sub_type_desc => oms_miscellaneous.getdesccode(
                                                                     p_domain        => 'TASK_SUBTYPE',
                                                                     p_refcode       => :new.case_note_sub_type,
                                                                     p_parent_domain => 'TASK_TYPE',
                                                                     p_parent_code   => :new.case_note_type),
                                      p_staff_id                => :new.staff_id,
                                      p_case_note_text          => :new.case_note_text,
                                      p_amendment_flag          => :new.amendment_flag,
                                      p_note_source_code        => :new.note_source_code,
                                      p_note_source_desc        => oms_miscellaneous.getdesccode('NOTE_SOURCE', :new.note_source_code)); 
   end if;

exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'CASE_NOTES_API_EVENT',
                                    p_message    => 'Error Updating case_note_id '||:new.case_note_id||':'||sqlerrm);
end;
/
show err
