create or replace trigger oms_owner.off_sub_accounts_api_event
after insert or update of balance
on oms_owner.offender_sub_accounts
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:    off_sub_accounts_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.0        17/08/2017    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);
   v_action varchar2(10);
   v_sub_account_type account_codes.sub_account_type%type;
   v_account_name     account_codes.account_name%type;
begin

   if api_owner.core_utils.is_digital_prison(:new.caseload_id) then 

      api_owner.core_utils.get_account_code_type(p_account_code     => :new.trust_account_code,
                                                 p_sub_account_type => v_sub_account_type,
                                                 p_account_name     => v_account_name);

      if  v_sub_account_type in ('REG','SPND','SAV') then
         --
         -- 
         api_owner.pss_events.sub_account_update(p_root_offender_id   => :new.offender_id,
                                                 p_agy_loc_id         => :new.caseload_id,
                                                 p_account_type       => v_sub_account_type,
                                                 p_account_type_desc  => v_account_name,
                                                 p_balance            => :new.balance);
      end if;
   end if;

exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_SUB_ACCOUNTS_API_EVENT',
                                    p_message    => 'Error '||v_action||' sub_account '||:new.trust_account_code||
                                                    ' for offender_id'||:new.offender_id||':'||
                                                    sqlerrm);
end;
/
show err
