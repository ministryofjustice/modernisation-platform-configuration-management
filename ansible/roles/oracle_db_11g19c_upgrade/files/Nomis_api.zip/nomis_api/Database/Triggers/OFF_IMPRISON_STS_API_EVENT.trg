create or replace trigger oms_owner.off_imprison_sts_api_event
after insert
on oms_owner.offender_imprison_statuses
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:  off_imprison_sts_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);

   v_convicted_status   varchar2(12);
   v_imprisonment_status imprisonment_statuses.description%type;
begin
   -- This trigger is required to fire during merge

   if api_owner.core_utils.is_in_digital_prison(:new.offender_book_id) then
      api_owner.pss_data_extractor.get_imp_status_desc(
                                             p_imprisonment_status => :new.imprisonment_status,
                                             p_imprisonment_desc   => v_imprisonment_status,
                                             p_convicted_status    => v_convicted_status);
      --
      -- Send transaction message to unilink
      api_owner.pss_events.offender_update(
                                   p_offender_book_id => :new.offender_book_id,
                                   p_imprison_status  => :new.imprisonment_status,
                                   p_convicted_status => v_convicted_status,
                                   p_imprison_status_desc =>  v_imprisonment_status);
   end if;

exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_IMPRISON_STS_API_EVENT',
                                    p_message    => 'Error Inserting imprisonment status '||:new.imprison_status_seq||
                                                    ' for offender_book_id  '||:new.offender_book_id||
                                                    ':'||sqlerrm);
end;
/
show err
