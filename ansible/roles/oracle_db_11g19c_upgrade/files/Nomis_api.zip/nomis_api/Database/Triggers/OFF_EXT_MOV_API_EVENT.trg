create or replace trigger oms_owner.off_ext_mov_api_event
before insert 
on oms_owner.offender_external_movements
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:  off_ext_mov_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);

   v_prev_agy_loc_id   agency_locations.agy_loc_id%type;
   v_prev_movement_time offender_external_movements.movement_time%type;
   v_prev_movement_type offender_external_movements.movement_type%type;
   v_prev_movement_reason offender_external_movements.movement_reason_code%type;

   --
	-- Check whether the prison is a digital prison
   --
	function is_digital_prison ( p_agy_loc_id in agency_locations.agy_loc_id%type) return boolean
	is
		l_dummy varchar2(1);
	begin
		select 'x'
		  into l_dummy
		  from agy_loc_establishments ale
		 where ale.agy_loc_id = p_agy_loc_id
		   and ale.establishment_type = 'DIG';

		return true;
	exception
		when no_data_found then
			return false;
	end is_digital_prison;

   --
   -- Check whether the offendrs last out movement was a court even or temporary absence
   -- from a digital prison
   --
   procedure check_last_out_movement(p_offender_book_id  in offender_bookings.offender_book_id%type,
                                p_prev_agy_loc_id  out agency_locations.agy_loc_id%type,
                                p_movement_time    out offender_external_movements.movement_time%type,
                                p_movement_type    out offender_external_movements.movement_type%type,
                                p_movement_reason  out offender_external_movements.movement_reason_code%type)
   is
      v_agy_loc_id agency_locations.agy_loc_id%type;
   begin
      select agy_loc_id, movement_type, movement_time, movement_reason_code
        into v_agy_loc_id, p_movement_type, p_movement_time, p_movement_reason
        from ( select oem.from_agy_loc_id agy_loc_id, oem.movement_type, oem.movement_reason_code, 
                      oem.movement_time,
                      row_number() over(order by oem.movement_date desc, oem.movement_time desc) rown
                 from offender_external_movements oem
                where oem.offender_book_id = p_offender_book_id
                  and oem.direction_code = 'OUT')
       where rown = 1;
   
      if p_movement_type in ('CRT','TAP') 
         and api_owner.core_utils.is_digital_prison(v_agy_loc_id) 
      then
         p_prev_agy_loc_id := v_agy_loc_id;
      end if;
   exception
      when no_data_found then
         p_prev_agy_loc_id := null;
   end check_last_out_movement;

begin
	-- Trigger not to fire during merge.movemnt_type 
   if sys_context('NOMIS','AUDIT_MODULE_NAME',50) in ('MERGE') then
      return;
   end if;

   if inserting then
		if :new.direction_code = 'IN'
		   and :new.movement_type IN ('TRN','ADM') 
      then
         if api_owner.core_utils.is_digital_prison(:new.to_agy_loc_id) then
            --
            -- Post reception event
            --
            api_owner.pss_events.reception(
                                 p_offender_book_id => :new.offender_book_id,
                                 p_agy_loc_id       => :new.to_agy_loc_id,
                                 p_movement_date    => :new.movement_date,
                                 p_movement_time    => :new.movement_time);
     --
         end if;
         --
         -- Check whether the offender was out at court from a digital prison
         --
         check_last_out_movement(p_offender_book_id  => :new.offender_book_id,
                                 p_prev_agy_loc_id   => v_prev_agy_loc_id,
                                 p_movement_time     => v_prev_movement_time,
                                 p_movement_type     => v_prev_movement_type,
                                 p_movement_reason   => v_prev_movement_reason);

         if api_owner.core_utils.is_digital_prison(v_prev_agy_loc_id) then
            --
            -- Post discharge Event
            --
            api_owner.pss_events.discharge(
                                 p_offender_book_id => :new.offender_book_id,
                                 p_agy_loc_id       => v_prev_agy_loc_id,
                                 p_movement_date    => v_prev_movement_time,
                                 p_movement_time    => v_prev_movement_time,
                                 p_movement_type     => v_prev_movement_type,
                                 p_movement_reason  => v_prev_movement_reason);
         end if;
         
      elsif :new.direction_code = 'OUT'
         and :new.movement_type IN ('TRN','REL')
      then 
         if api_owner.core_utils.is_digital_prison(:new.from_agy_loc_id) then
            --
            -- Post discharge Event
            --
            api_owner.pss_events.discharge(
                                 p_offender_book_id => :new.offender_book_id,
                                 p_agy_loc_id       => :new.from_agy_loc_id,
                                 p_movement_date    => :new.movement_date,
                                 p_movement_time    => :new.movement_time,
                                 p_movement_type    => :new.movement_type,
                                 p_movement_reason  => :new.movement_reason_code);
         end if;
      end if;
   end if;
exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_EXT_MOV_API_EVENT',
                                    p_message    => 'Error Inserting movement '||:new.movement_seq||
                                                    ' for offender_book_id '||:new.offender_book_id||
                                                    ':'||sqlerrm);
end;
/
show err
