create or replace trigger oms_owner.off_oic_sanction_api_event

after insert 
on oms_owner.offender_oic_sanctions
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:  off_oic_sanction_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);

   v_offender_book_id offender_bookings.offender_book_id%type;
   v_agy_loc_id offender_bookings.agy_loc_id%type;
begin
   -- This trigger is required to fire during merge

   if :new.oic_sanction_code in ('CANTEEN')
      and :new.effective_date <= trunc(sysdate)
      and (add_months(:new.effective_date,:new.sanction_months) + :new.sanction_days) >= trunc(sysdate)
   then
          
      if api_owner.core_utils.is_in_digital_prison(p_offender_book_id => v_offender_book_id) then
         --
         -- Send transaction message to unilink
         --
         api_owner.pss_events.offender_update(p_offender_book_id => v_offender_book_id,
                                      p_canteen_sanction => true);
      end if;
   end if; 
   
exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_OIC_SANCTION_API_EVENT',
                                    p_message    => 'Error Inserting sanction '||:new.sanction_seq||
                                                    ' for offender_book_id '||:new.offender_book_id||
                                                    ':'||sqlerrm);
end;
/
show err
