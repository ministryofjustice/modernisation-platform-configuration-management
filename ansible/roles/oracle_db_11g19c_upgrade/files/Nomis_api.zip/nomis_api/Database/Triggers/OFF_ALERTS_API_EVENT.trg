create or replace trigger oms_owner.off_alerts_api_event
after delete or insert or update of expiry_date, alert_status 
on oms_owner.offender_alerts
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:  off_alerts_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);
   v_action varchar2(10);
   v_offender_book_id offender_bookings.offender_book_id%type;
   v_alert_seq        offender_alerts.alert_seq%type;
begin
   -- This trigger is required to fire during merge


   if inserting 
      and api_owner.core_utils.is_in_digital_prison(:new.offender_book_id) 
      and :new.alert_status = 'ACTIVE'
   then
      v_action := 'Inserting';
      v_offender_book_id := :new.offender_book_id;
      v_alert_seq  := :new.alert_seq;
      --
      -- Send transaction message to unilink
      api_owner.pss_events.offender_update(
            p_offender_book_id      => :new.offender_book_id,
            p_warning_type          => :new.alert_type,
            p_warning_type_desc     => oms_miscellaneous.getdesccode('ALERT', :new.alert_type),
            p_warning_sub_type      => :new.alert_code,
            p_warning_sub_type_desc => oms_miscellaneous.getdesccode(p_domain        => 'ALERT_CODE',
                                                                     p_refcode       => :new.alert_code,
                                                                     p_parent_domain => 'ALERT',
                                                                     p_parent_code   => :new.alert_type),
            p_warning_date          => :new.alert_date,
            p_expiry_date           => :new.expiry_date,
            p_status                => :new.alert_status);
   end if;

   if updating 
      and api_owner.core_utils.is_in_digital_prison(:new.offender_book_id) 
   then
      v_action := 'Updating';
      v_offender_book_id := :new.offender_book_id;
      v_alert_seq  := :new.alert_seq;
      --
      -- Send transaction message to unilink
      api_owner.pss_events.offender_update(
            p_offender_book_id      => :old.offender_book_id,
            p_warning_type          => :old.alert_type,
            p_warning_type_desc     => oms_miscellaneous.getdesccode('ALERT', :old.alert_type),
            p_warning_sub_type      => :old.alert_code,
            p_warning_sub_type_desc => oms_miscellaneous.getdesccode(p_domain        => 'ALERT_CODE',
                                                                     p_refcode       => :old.alert_code,
                                                                     p_parent_domain => 'ALERT',
                                                                     p_parent_code   => :old.alert_type),
            p_warning_date          => :old.alert_date,
            p_expiry_date           => :new.expiry_date,
            p_status                => :new.alert_status);
   end if;

   if deleting
      and api_owner.core_utils.is_in_digital_prison(:old.offender_book_id) 
   then
      v_action := 'Deleting';
      v_offender_book_id := :old.offender_book_id;
      v_alert_seq  := :old.alert_seq;
      --
      -- Send transaction message to unilink
      api_owner.pss_events.offender_update(
            p_offender_book_id      => :old.offender_book_id,
            p_warning_type          => :old.alert_type,
            p_warning_type_desc     => oms_miscellaneous.getdesccode('ALERT', :old.alert_type),
            p_warning_sub_type      => :old.alert_code,
            p_warning_sub_type_desc => oms_miscellaneous.getdesccode(p_domain        => 'ALERT_CODE',
                                                                     p_refcode       => :old.alert_code,
                                                                     p_parent_domain => 'ALERT',
                                                                     p_parent_code   => :old.alert_type),
            p_warning_date          => :old.alert_date,
            p_status                => 'DELETED');
   
   end if;


exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_ALERTS_API_EVENT',
                                    p_message    => 'Error '||v_action||' alert '||v_alert_seq||
                                                    ' for offender_book_id '||v_offender_book_id||':'||
                                                    sqlerrm);
end;
/
show err
