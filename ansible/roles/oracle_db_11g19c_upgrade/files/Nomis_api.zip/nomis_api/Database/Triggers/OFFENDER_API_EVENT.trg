create or replace trigger oms_owner.offender_api_event
after update of race_code, offender_id_display, first_name, sex_code, title, middle_name, middle_name_2, last_name, suffix, birth_date
on oms_owner.offenders
referencing new as new old as old
for each row
declare
/******************************************************************************
   Name:  offender_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.4        16/02/2017    Kumar            Removed SOI related code
   1.3        03/02/2017    Kumar            Added race_code to SOI code
   1.2        24/01/2017    Kumar            Merged PSS and SOI related code.
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/
   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);

   v_offender_book_id offender_bookings.offender_book_id%type;
   v_root_offender_id offender_bookings.root_offender_id%type;
   v_agy_loc_id offender_bookings.agy_loc_id%type;
   v_middle_name   VARCHAR2 (100);

   function new_or_null(p_old_string varchar2, p_new_string varchar2) return varchar2
   is
   begin
      if p_old_string = p_new_string then
         return null;
      else
         return p_new_string;
      end if;
   end new_or_null;

   function new_or_null_desc(p_domain varchar2, p_old_code varchar2, p_new_code varchar2) return varchar2
   is
   begin
      if p_old_code = p_new_code then
         return null;
      else
         return oms_miscellaneous.getdesccode(p_domain,p_new_code);
      end if;
   end new_or_null_desc;

begin
   -- This trigger is required to fire during merge
   --
   -- Check that this is the working name and get
   -- the offender_book_id, root_offender_id and agy_loc_id
   --
   select offender_book_id,root_offender_id,agy_loc_id
     into v_offender_book_id, v_root_offender_id, v_agy_loc_id
     from offender_bookings
    where offender_id =:old.offender_id
      and booking_seq = 1;

   if api_owner.core_utils.is_in_digital_prison(p_offender_book_id => v_offender_book_id) then
      if nvl(:new.race_code,'XYZ') != nvl(:old.race_code,'XYZ') 
         or :new.first_name != :old.first_name
         or :new.sex_code != :old.sex_code
      then
         --
         -- Create row in api_offender_events table
         --
         api_owner.pss_events.offender_update(p_offender_book_id => v_offender_book_id,
                                      p_offender_id      => :old.offender_id,
                                      p_root_offender_id => :old.root_offender_id,
                                      p_noms_id          => :old.offender_id_display,
                                      p_first_name       => new_or_null(:old.first_name, :new.first_name),
                                      p_agy_loc_id       => v_agy_loc_id,
                                      p_sex_code         => new_or_null(:old.sex_code, :new.sex_code),
                                      p_sex_desc         => new_or_null_desc('SEX',:old.sex_code,:new.sex_code),
                                      p_ethnicity        => new_or_null(:old.race_code,:new.race_code),
                                      p_ethnicity_desc   => new_or_null_desc('ETHNICITY',:old.race_code,:new.race_code));

      elsif :old.offender_id_display != :new.offender_id_display then
         --
         -- Create row in api_offender_events table
         --
         api_owner.pss_events.noms_id_update(p_old_noms_id        => :old.offender_id_display,
                                             p_new_noms_id        => :new.offender_id_display,
                                             p_root_offender_id   => v_root_offender_id,
                                             p_agy_loc_id         => v_agy_loc_id);
      end if;
   end if;
      
exception
   when no_data_found then
      --
      -- This isn't the working name take no action
      --
      null;
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFFENDER_API_EVENT',
                                    p_message    => 'Error Updating offender_id '||:new.offender_id||':'||sqlerrm);
end;
/
show err
