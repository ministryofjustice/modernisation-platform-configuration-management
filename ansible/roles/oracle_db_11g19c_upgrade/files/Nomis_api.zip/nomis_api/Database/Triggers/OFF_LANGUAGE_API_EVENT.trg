create or replace trigger oms_owner.off_language_api_event
after insert or update of language_code
on oms_owner.offender_languages
referencing new as new old as old
for each row
when (new.language_type = 'PREF_SPEAK')
declare
/******************************************************************************
   Name:  off_language_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);
   v_action varchar2(10);
begin
   -- Trigger required to fire during merge

   if updating then
      v_action := 'Updating';
      if api_owner.core_utils.is_in_digital_prison(:old.offender_book_id) then
         if :new.language_code != :old.language_code then 
            --
            -- Send transaction message to unilink
            --
            api_owner.pss_events.offender_update(p_offender_book_id => :old.offender_book_id,
                                         p_language         => :new.language_code,
                                         p_language_desc    => oms_miscellaneous.getdesccode('LANG',:new.language_code));
         end if;
      end if;
   else
      v_action := 'Inserting';
      if api_owner.core_utils.is_in_digital_prison(:new.offender_book_id) then
         --
         -- Send transaction message to unilink
         --
         api_owner.pss_events.offender_update(p_offender_book_id => :new.offender_book_id,
                                      p_language         => :new.language_code,
                                      p_language_desc    => oms_miscellaneous.getdesccode('LANG',:new.language_code));
      end if;

   end if;

exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_LANGUAGE_API_EVENT',
                                    p_message    => 'Error '||v_action||' '||:new.language_type||' language '||
                                                     :new.language_code||' for offender_book_id '||:new.offender_book_id||
                                                     ':'||sqlerrm);
end;
/
show err
