create or replace trigger oms_owner.off_prof_details_api_event
after insert or update of profile_code
on oms_owner.offender_profile_details
referencing new as new old as old
for each row
when (new.profile_type in ('DIET','RELF','NAT','NATIO'))
declare
/******************************************************************************
   Name:  off_prof_details_api_event
   PURPOSE: This trigger is part of the api_events interface

   Revisions:
   Ver        Date          Author           Description
   ---------  ------------  ---------------  ------------------------------------
   1.3        16/02/2017    Kumar            Removed SOI related code
   1.2        24/01/2017    Kumar            Merged PSS and SOI related code   
   1.1        12/12/2016    Paul Morris      Improved logged message content
   1.0        29/07/2016    Paul Morris      Initial version
******************************************************************************/

   cannot_find_program EXCEPTION;
   PRAGMA EXCEPTION_INIT(cannot_find_program , -06508);
   v_noms_id   offenders.offender_id_display%TYPE;
   v_offender_id offenders.offender_id%type;


   function code_changed(p_type varchar2) 
      return varchar2
   is
      v_new_profile offender_profile_details.profile_code%type;
   begin
      if :new.profile_type = p_type 
         and nvl(:new.profile_code,'ZXY') != nvl(:old.profile_code,'ZXY')
      then
         return :new.profile_code;
      else
         return null;
      end if;
   end code_changed;

begin

   -- Trigger not to fire during merge
   if sys_context('NOMIS','AUDIT_MODULE_NAME',50) in ('MERGE') then
      return;
   end if;

   if updating then
      if api_owner.core_utils.is_in_digital_prison(:old.offender_book_id) then
         --
         -- Send transaction message to unilink
         api_owner.pss_events.offender_update(
               p_offender_book_id => :old.offender_book_id,
               p_diet             => code_changed('DIET'),
               p_diet_desc        => api_owner.pss_data_extractor.get_profile_code_desc('DIET',code_changed('DIET')),
               p_religion         => code_changed('RELF'),
               p_religion_desc    => api_owner.pss_data_extractor.get_profile_code_desc('RELF',code_changed('RELF')),
               p_nationality      => case 
                                        when code_changed('NATIO') is not null then 'MULTI'
                                        else code_changed('NAT')
                                     end,
               p_nationality_desc => nvl(code_changed('NATIO'),
                                         api_owner.pss_data_extractor.get_profile_code_desc('NAT',code_changed('NAT'))));
      end if;

   end if;
   
   
exception
   when cannot_find_program  then
      -- this needs to propagate so it rectifies itself
      raise;
   when others then
      api_owner.nomis_api_log.error(p_msg_module => 'OFF_PROF_DETAILS_API_EVENT',
                                    p_message    => 'Error updating profile '||:new.profile_seq||'/'||:new.profile_type||
                                                    ' for offender_book_id '||:new.offender_book_id||
                                                    ':'||sqlerrm);
end;
/
show err
