alter table api_owner.api_offender_events
  add (event_data_1 varchar2(4000),
       event_data_2 varchar2(4000),
       event_data_3 varchar2(4000));
