alter table api_owner.api_offender_events set unused column event_data;
