-- Run as oms_owner or sysdba
SPOOL nomis_api_install.log
--
PROMPT grant permissions to api_owner schema
--
@@DDL/API_OWNER_GRANTS.sql
--
PROMPT create api_owner tables
--
@@Tables/API_STORED_PAYMENTS.tab
@@DDL/API_STORED_PAYMENT_ID.seq
--
PROMPT create api_owner packages
--
@@Packages/CORE_UTILS.pkg
@@Packages/API_FINANCE_PROCS.pkg
@@Packages/NOMIS_API_BATCH.pkg
--
PROMPT create synonyms for api_owner packages
--
@@DDL/API_OWNER_SYNONYMS.sql
--
PROMPT grant execute permissions on packages to api_user schema
--
@@DDL/API_USER_GRANTS.sql

--
PROMPT set up reference data
--
@@DDL/API_REF_DATA.sql
--
PROMPT set up each digital prison
--
@@DDL/DIGITAL_PRISON_SETUP.sql WCI
spool off
