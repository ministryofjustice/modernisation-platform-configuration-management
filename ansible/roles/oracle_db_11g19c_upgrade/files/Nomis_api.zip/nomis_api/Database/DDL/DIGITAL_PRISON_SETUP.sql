--09NOV2016
--Added 2 more transactions type, have made it rerunable and removed multiple commits.

--Added module type to the subquery to make it rerunable.


set define on
var prison varchar2(12)
begin
   :prison := upper('&1');
end;
/
set define off;
insert into oms_owner.agy_loc_establishments (agy_loc_id, establishment_type)
select :prison, 'DIG'
  from dual
 where not exists (select null 
                     from oms_owner.agy_loc_establishments
                    where agy_loc_id = :prison
                      and establishment_type = 'DIG');

insert into oms_owner.transaction_operations
   (module_name, txn_type, txn_operation_seq, dr_account_code, cr_account_code, 
    invalid_accounts_flag, cheque_production_flag, receipt_production_flag, update_allowed_flag, 
    list_seq, caseload_id, modify_date)
select 'NOMISAPI', 'A_EARN', 1, 1501, 2102, 'N', 'Y', 'N', 'Y', 99, :prison, trunc(sysdate)
  from dual
 where not exists (select null
                     from oms_owner.transaction_operations
                    where caseload_id = :prison
                      and module_name = 'NOMISAPI'
                      and txn_type = 'A_EARN');

insert into oms_owner.transaction_operations
   (module_name, txn_type, txn_operation_seq, dr_account_code, cr_account_code, 
    invalid_accounts_flag, cheque_production_flag, receipt_production_flag, update_allowed_flag, 
    list_seq, caseload_id, modify_date)
select 'NOMISAPI', 'CANT', 1, 2102, 2501, 'N', 'N', 'N', 'Y', 99, :prison, trunc(sysdate)
  from dual
 where not exists (select null
                     from oms_owner.transaction_operations
                    where caseload_id = :prison
                      and module_name = 'NOMISAPI'
                      and txn_type = 'CANT');

insert into oms_owner.transaction_operations
   (module_name, txn_type, txn_operation_seq, dr_account_code, cr_account_code, 
    invalid_accounts_flag, cheque_production_flag, receipt_production_flag, update_allowed_flag, 
    list_seq, caseload_id, modify_date)
select 'NOMISAPI', 'PHONE', 99, 2102, 2502, 'N', 'Y', 'N', 'Y', 99, :prison, trunc(sysdate)
  from dual
 where not exists (select null
                     from oms_owner.transaction_operations
                    where caseload_id = :prison
                      and module_name = 'NOMISAPI'
                      and txn_type = 'PHONE');

insert into oms_owner.transaction_operations
   (module_name, txn_type, txn_operation_seq, dr_account_code, cr_account_code, 
    invalid_accounts_flag, cheque_production_flag, receipt_production_flag, update_allowed_flag, 
    list_seq, caseload_id, modify_date)
select 'NOMISAPI', 'ADJ', 99, 2102, 1501, 'N', 'N', 'N', 'Y', 99, :prison, trunc(sysdate)
  from dual
 where not exists (select null
                     from oms_owner.transaction_operations
                    where caseload_id = :prison
                      and module_name = 'NOMISAPI'
                      and txn_type = 'ADJ');


insert into oms_owner.transaction_operations
   (module_name, txn_type, txn_operation_seq, dr_account_code, cr_account_code, 
    invalid_accounts_flag, cheque_production_flag, receipt_production_flag, update_allowed_flag, 
    list_seq, caseload_id, modify_date)
select 'NOMISAPI', 'REFND', 99, 2501, 2102, 'N', 'N', 'N', 'Y', 99, :prison, trunc(sysdate)
  from dual
 where not exists (select null
                     from oms_owner.transaction_operations
                    where caseload_id = :prison
                      and module_name = 'NOMISAPI'
                      and txn_type = 'REFND');
commit;
