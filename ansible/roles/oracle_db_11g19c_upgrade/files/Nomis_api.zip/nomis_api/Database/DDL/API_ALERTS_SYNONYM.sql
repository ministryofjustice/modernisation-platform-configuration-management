-- run as oms_owner or sysdba
create or replace synonym api_user.api_alerts for api_owner.api_alerts;

