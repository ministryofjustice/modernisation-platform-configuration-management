drop index api_owner.api_offender_events_ni1;

create index api_owner.api_offender_events_ni1 on api_owner.api_offender_events
(event_timestamp, agy_loc_id )
logging
tablespace tag_indx;
