-- run as oms_owner or sysdba
create or replace synonym api_user.api_core_procs for api_owner.api_core_procs;
create or replace  synonym api_user.api_visit_procs for api_owner.api_visit_procs;
create or replace synonym api_user.api_finance_procs for api_owner.api_finance_procs;
create or replace synonym api_user.api_offender_event for api_owner.api_offender_event;
create or replace synonym api_user.api_offender_procs for api_owner.api_offender_procs;
create or replace synonym api_user.api_prison_procs for api_owner.api_prison_procs;
create or replace synonym api_user.api_booking_procs for api_owner.api_booking_procs;
create or replace synonym api_user.api_legal_procs for api_owner.api_legal_procs;
create or replace synonym api_user.api_metadata for api_owner.api_metadata;
create or replace synonym api_user.api_ref_data for api_owner.api_ref_data;
create or replace synonym api_user.api_offender_contacts for api_owner.api_offender_contacts;
create or replace synonym api_user.api_case_notes for api_owner.api_case_notes;

create or replace synonym api_proxy_user.api_core_procs for api_owner.api_core_procs;
create or replace  synonym api_proxy_user.api_visit_procs for api_owner.api_visit_procs;
create or replace synonym api_proxy_user.api_finance_procs for api_owner.api_finance_procs;
create or replace synonym api_proxy_user.api_offender_event for api_owner.api_offender_event;
create or replace synonym api_proxy_user.api_offender_procs for api_owner.api_offender_procs;
create or replace synonym api_proxy_user.api_prison_procs for api_owner.api_prison_procs;
create or replace synonym api_proxy_user.api_booking_procs for api_owner.api_booking_procs;
create or replace synonym api_proxy_user.api_legal_procs for api_owner.api_legal_procs;
create or replace synonym api_proxy_user.api_metadata for api_owner.api_metadata;
create or replace synonym api_proxy_user.api_ref_data for api_owner.api_ref_data;
create or replace synonym api_proxy_user.api_offender_contacts for api_owner.api_offender_contacts;
create or replace synonym api_proxy_user.api_case_notes for api_owner.api_case_notes;
