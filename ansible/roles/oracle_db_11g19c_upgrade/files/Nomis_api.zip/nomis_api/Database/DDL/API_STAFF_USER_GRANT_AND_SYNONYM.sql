-- run as oms_owner or sysdba
grant execute on api_owner.api_staff to api_user;
create or replace synonym api_user.api_staff for api_owner.api_staff;
