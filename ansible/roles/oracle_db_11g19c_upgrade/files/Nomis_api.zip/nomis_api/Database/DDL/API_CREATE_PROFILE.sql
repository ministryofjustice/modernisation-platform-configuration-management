--Create a new porifle with password unliited for API
create profile api_user_profile limit
  sessions_per_user default
  cpu_per_session default
  cpu_per_call default
  connect_time default
  idle_time unlimited
  logical_reads_per_session default
  logical_reads_per_call default
  composite_limit default
  private_sga default
  failed_login_attempts unlimited
  password_life_time unlimited
  password_reuse_time unlimited
  password_reuse_max unlimited
  password_lock_time unlimited
  password_grace_time unlimited
  password_verify_function default;
