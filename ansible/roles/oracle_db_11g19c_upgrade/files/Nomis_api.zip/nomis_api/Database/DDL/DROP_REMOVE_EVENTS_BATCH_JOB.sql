begin
  sys.dbms_scheduler.drop_job(
       job_name        => 'API_OWNER.REMOVE_OLD_EVENTS');
end;
/
