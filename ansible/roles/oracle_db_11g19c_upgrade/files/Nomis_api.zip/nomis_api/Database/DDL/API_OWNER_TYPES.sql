
create or replace type api_owner.integer_varray as varray(10) of integer
/
create or replace type api_owner.integer_table as table of integer
/
create or replace type api_owner.varchar100_table as table of varchar2(100)
/
