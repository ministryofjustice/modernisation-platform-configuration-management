-- run as oms_owner or sysdba
grant execute on api_owner.api_core_procs to api_user;
grant execute on api_owner.api_visit_procs to api_user;
