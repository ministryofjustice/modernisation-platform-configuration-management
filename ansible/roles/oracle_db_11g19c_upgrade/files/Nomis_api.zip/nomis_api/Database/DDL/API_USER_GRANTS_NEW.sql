-- run as oms_owner or sysdba
grant execute on api_owner.api_core_procs to api_user;
grant execute on api_owner.api_visit_procs to api_user;
grant execute on api_owner.api_finance_procs to api_user;
grant execute on api_owner.api_offender_event to api_user;
grant execute on api_owner.api_offender_procs to api_user;
grant execute on api_owner.api_prison_procs to api_user;

-- Added for release 1.3.0
grant execute on api_owner.api_booking_procs to api_user;
grant execute on api_owner.api_legal_procs to api_user;

-- Added for release 1.13.0
grant execute on api_owner.api_metadata to api_user;

-- Added for release 1.15.0
grant execute on api_owner.api_ref_data to api_user;
grant execute on api_owner.api_offender_contacts to api_user;

-- Added for release 1.18.0
grant execute on api_owner.api_case_notes to api_user;
