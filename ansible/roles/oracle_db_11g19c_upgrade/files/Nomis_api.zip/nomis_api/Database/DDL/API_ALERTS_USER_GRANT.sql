-- run as oms_owner or sysdba
grant execute on api_owner.api_alerts to api_user;
