--09NOV2016
--Made it Rerunable.

PROMPT Create Digital prison Establishment type

insert into oms_owner.reference_codes
       (domain, code, description, list_seq, active_flag, system_data_flag)
select 'ESTAB_TYPE', 'DIG', 'Digital Prison ', 2, 'Y', 'Y'
  from dual
 where not exists (select null
                     from oms_owner.reference_codes
                    where domain = 'ESTAB_TYPE'
                      and code = 'DIG');
commit;

PROMPT Registering new module, NOMISAPI - for Nomis API Transactions

insert into oms_owner.oms_modules (module_name, description, module_type, call_form)
select 'NOMISAPI','Nomis API web service','SCREEN', 'N'
  from dual
 where not exists (select null
                     from oms_modules o
                    where o.module_name = 'NOMISAPI');
commit;
