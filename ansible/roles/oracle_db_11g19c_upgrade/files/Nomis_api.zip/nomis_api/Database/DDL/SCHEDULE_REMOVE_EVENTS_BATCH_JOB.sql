begin
  sys.dbms_scheduler.create_job(
       job_name        => 'API_OWNER.REMOVE_OLD_EVENTS',
       start_date      => trunc(sysdate),
       repeat_interval => 'FREQ=DAILY; BYHOUR=0;BYMINUTE=10;BYSECOND=0',
       end_date        => NULL,
       job_class       => 'DEFAULT_JOB_CLASS',
       job_type        => 'PLSQL_BLOCK',
       job_action      => 'begin api_owner.nomis_api_batch.remove_old_events; end;',
      comments        => 'Remove old API events' );
end;
/
