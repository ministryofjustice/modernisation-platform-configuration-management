-- run as oms_owner or sysdba
create user api_owner identified by api_owner;
grant resource to api_owner;

create user api_user identified by api_user;
grant connect to api_user;
