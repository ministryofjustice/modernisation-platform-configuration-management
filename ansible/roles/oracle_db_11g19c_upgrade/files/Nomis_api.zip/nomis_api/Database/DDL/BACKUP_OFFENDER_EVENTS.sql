create table api_owner.api_offender_events_backup 
    as select * from api_owner.api_offender_events;
