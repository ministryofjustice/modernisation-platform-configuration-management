--Attach user to api user profile.
alter user api_user profile api_user_profile;  
