-- run as sysdba
grant select on oms_owner.offenders to api_owner;
grant select on oms_owner.offender_bookings to api_owner;
grant select on oms_owner.offence_result_codes to api_owner;
grant select on oms_owner.offender_charges to api_owner;
grant select on oms_owner.court_event_charges to api_owner;
grant select on oms_owner.court_events to api_owner;
grant select on oms_owner.offender_sentence_charges to api_owner;
grant select on oms_owner.offender_sentences to api_owner;
grant select on oms_owner.offender_profile_details to api_owner;
grant select on oms_owner.profile_codes to api_owner;
grant select on oms_owner.offender_imprison_statuses to api_owner;
grant select on oms_owner.imprisonment_statuses to api_owner;
grant select on oms_owner.agency_locations to api_owner;
grant select on oms_owner.offender_non_associations to api_owner;

grant select on oms_owner.offender_visits to api_owner;
grant select on oms_owner.offender_visit_visitors to api_owner;
grant select on oms_owner.offender_restrictions to api_owner;
grant select on oms_owner.offender_visit_balances to api_owner;
grant select on oms_owner.agency_visit_times  to api_owner;
grant select on oms_owner.agency_visit_slots  to api_owner;
grant select on oms_owner.agency_internal_locations  to api_owner;
grant select on oms_owner.internal_location_usages  to api_owner;
grant select on oms_owner.int_loc_usage_locations  to api_owner;
-- Added insert for 1.15.0
grant select, insert on oms_owner.offender_contact_persons  to api_owner;
grant select, insert on oms_owner.persons  to api_owner;

-- Additional grants required for 1.1.0
-- Amended for 1.14.0
grant insert, update,  select on oms_owner.offender_transactions to api_owner;
grant select on  oms_owner.txn_id to api_owner;
grant select on  oms_owner.transaction_operations to api_owner;
grant select on  oms_owner.transaction_types to api_owner;
grant update, select on  oms_owner.offender_trust_accounts to api_owner;
-- Amended for 1.14.0
grant update, select on  oms_owner.offender_sub_accounts to api_owner;
grant select on  oms_owner.account_codes to api_owner;
grant select on  oms_owner.gl_transactions to api_owner;
grant execute on oms_owner.trust to api_owner;
grant execute on oms_owner.otdrdtfu to api_owner;
grant execute on oms_owner.deductions to api_owner;
grant execute on oms_owner.financial to api_owner;
grant select on oms_owner.job_controls to api_owner;
grant select on oms_owner.caseloads to api_owner;
grant execute on oms_owner.nomis_context to api_owner;
grant execute on oms_owner.tag_batch_job_control to api_owner;
grant execute on oms_owner.tag_application_log to api_owner;

-- Additional grants required for 1.2.0
grant select on oms_owner.offender_external_movements to api_owner;
grant select on oms_owner.offender_assessments to api_owner;
grant select on oms_owner.offender_languages to api_owner;
grant select on oms_owner.offender_iep_levels to api_owner;
grant select on oms_owner.offender_alerts to api_owner;
grant select on oms_owner.offender_oic_sanctions to api_owner;
grant select on oms_owner.offender_case_officers to api_owner;
grant select on oms_owner.staff_members to api_owner;
grant select on oms_owner.movement_reasons to api_owner;
grant select on oms_owner.assessments to api_owner;
grant select on oms_owner.iep_levels to api_owner;
grant select on oms_owner.agy_loc_establishments to api_owner;

-- Additional grants required for 1.3.0
grant select on oms_owner.offender_images to api_owner;
grant select on oms_owner.offender_identifiers to api_owner;
grant select on oms_owner.offender_cases to api_owner;
grant select on oms_owner.offences to api_owner;
grant select on oms_owner.statutes to api_owner;
grant select on oms_owner.imprison_status_mappings to api_owner;
grant select on oms_owner.offender_release_details to api_owner;

-- Additional grants required for 1.6.0
grant select on oms_owner.visitor_restrictions to api_owner;
grant select on oms_owner.offender_person_restricts to api_owner;

-- Additional grants required for 1.7.0
grant select, insert, update on offender_visits to api_owner;
grant select, insert, update on offender_visit_visitors to api_owner;
grant select, insert, update on offender_visit_orders to api_owner;
grant select on event_id to api_owner;
grant select on offender_visit_visitor_id to api_owner;
grant select on offender_visit_order_id to api_owner;
grant select on offender_visit_id to api_owner;
grant select on visit_order_number to api_owner;
grant select on offender_vo_visitor_id to api_owner;
grant select on offender_visit_visitor_id to api_owner;
grant select on offender_visit_balance_adj_id to api_owner;
grant select, insert on offender_vo_visitors to api_owner;
grant select, insert on offender_visit_balance_adjs to api_owner;
grant select on offender_non_associations to api_owner;
grant select on offender_na_details to api_owner;
grant select on staff_user_accounts to api_owner;
grant select on visitor_restrictions to api_owner;
grant select on system_profiles to api_owner;

-- Additional grants required for 1.10.0
grant select on oms_owner.offender_case_notes to api_owner;

-- Aditionmal grants required for 1.13.0
grant select on sys.v_$instance to api_owner;
grant select on sys.v_$database to api_owner;

-- Additional grants required for 1.15.0
grant execute on oms_owner.tag_error to api_owner;
grant select, insert on oms_owner.addresses to api_owner;
grant select, insert on oms_owner.phones to api_owner;
grant select, insert on oms_owner.internet_addresses to api_owner;
grant select on oms_owner.person_id to api_owner;
grant select on oms_owner.address_id to api_owner;
grant select on oms_owner.phone_id to api_owner;
grant select on oms_owner.internet_address_id to api_owner;
grant select on oms_owner.offender_contact_person_id to api_owner;
grant select on oms_owner.contact_person_types to api_owner;

-- Additional grants required for 1.17.0
grant execute on oms_owner.trust_auto_transfer to api_owner;
