-- run as oms_owner or sysdba
declare
   user_doesnt_exist exception;
   pragma exception_init(user_doesnt_exist, -01918);
begin
   execute immediate 'drop user api_user cascade';
   execute immediate 'drop user api_owner cascade';
exception
   when user_doesnt_exist then
      null;
end;
/
