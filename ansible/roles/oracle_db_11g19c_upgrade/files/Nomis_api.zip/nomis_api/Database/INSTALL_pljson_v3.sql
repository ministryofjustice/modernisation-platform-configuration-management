-- Run as sys or oms_owner
-- from Database folder
--
-- Uninstall previous version and install pl/json version 3  
--
column curr_schema new_value prev_schema noprint
select user curr_schema from dual;
alter session set current_schema = api_owner;

PROMPT --------------------------------------------;
PROMPT -- Uninstall existing objects for PL/JSON --;
PROMPT --------------------------------------------;
@@pljson-master/uninstall.sql

ALTER SESSION SET PLSQL_OPTIMIZE_LEVEL = 2;

/*
This software has been released under the MIT license:

  Copyright (c) 2010 Jonas Krogsboell inspired by code from Lewis R Cunningham

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.
*/
PROMPT -----------------------------------;
PROMPT -- Compiling objects for PL/JSON --;
PROMPT -----------------------------------;
-- @@pljson-develop_v3/uninstall.sql

@@pljson-develop_v3/src/pljson_element.type.decl.sql
@@pljson-develop_v3/src/pljson_list.type.decl.sql
@@pljson-develop_v3/src/pljson.type.decl.sql
@@pljson-develop_v3/src/pljson_string.type.sql
@@pljson-develop_v3/src/pljson_number.type.sql
@@pljson-develop_v3/src/pljson_bool.type.sql
@@pljson-develop_v3/src/pljson_null.type.sql
@@pljson-develop_v3/src/pljson_ext.decl.sql
@@pljson-develop_v3/src/pljson_parser.decl.sql
@@pljson-develop_v3/src/pljson_parser.impl.sql
@@pljson-develop_v3/src/pljson_printer.package.sql
@@pljson-develop_v3/src/pljson_ext.impl.sql
@@pljson-develop_v3/src/pljson_element.type.impl.sql
@@pljson-develop_v3/src/pljson_list.type.impl.sql
@@pljson-develop_v3/src/pljson.type.impl.sql

/* @@src/pljson_ac.package.sql --wrapper to enhance autocompletion */

PROMPT ------------------------------------------;
PROMPT -- Adding optional packages for PL/JSON --;
PROMPT ------------------------------------------;
@@pljson-develop_v3/src/addons/pljson_dyn.package.sql --dynamic sql execute
@@pljson-develop_v3/src/addons/pljson_ml.package.sql  --jsonml (xml to json)
@@pljson-develop_v3/src/addons/pljson_xml.package.sql --json to xml copied from http://www.json.org/java/org/json/XML.java
@@pljson-develop_v3/src/addons/pljson_util_pkg.package.sql --dynamic sql from http://ora-00001.blogspot.com/2010/02/ref-cursor-to-json.html
@@pljson-develop_v3/src/addons/pljson_helper.package.sql   --set operations on JSON and JSON_LIST
@@pljson-develop_v3/src/addons/pljson_object_cache.decl.sql    -- object cache
@@pljson-develop_v3/src/addons/pljson_object_cache.impl.sql    -- object cache
@@pljson-develop_v3/src/addons/pljson_table_impl.type.decl.sql -- dynamic table from json document
@@pljson-develop_v3/src/addons/pljson_table_impl.type.impl.sql -- dynamic table from json document

/* @@testsuite/pljson_ut.package.sql -- pljson unit test mini framework */

PROMPT ------------------------------;
PROMPT -- Update affected packages --;
PROMPT ------------------------------;
@@Packages/JSON_BUILDER.pkg
@@Packages/API_OFFENDER_PROCS.pkg
@@Packages/PSS_EVENTS.pkg
@@Packages/API_EVENTS.pkg

-- Change schema back to previous
set define on
alter session set current_schema = &prev_schema;
--
-- End of pl/json install
--
