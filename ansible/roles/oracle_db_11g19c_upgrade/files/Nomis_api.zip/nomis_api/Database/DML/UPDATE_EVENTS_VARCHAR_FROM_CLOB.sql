
update api_owner.api_offender_events
  set event_data_1 = DBMS_LOB.SUBSTR(event_data, 4000, 1),
      event_data_2 =DBMS_LOB.SUBSTR(event_data, 4000, 4001),
      event_data_3 = DBMS_LOB.SUBSTR(event_data, 4000, 8001)
 where event_data_1 is null;
commit;
