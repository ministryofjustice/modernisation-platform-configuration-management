declare
   --
   -- Sets up all the transaction types that can be posted via the Nomis API for all prisons
   -- These transaction types are: 
   --    HOA
   --    HOR
   --
   procedure insert_transaction_operation(p_module_name in transaction_operations.module_name%type,
                                          p_caseload_id  in transaction_operations.caseload_id%type,
                                          p_txn_type in transaction_operations.txn_type%type,
                                          p_dr_account_code in transaction_operations.dr_account_code%type,
                                          p_cr_account_code  in transaction_operations.cr_account_code%type,
                                          p_invalid_accounts_flag  in transaction_operations.invalid_accounts_flag%type,
                                          p_cheque_production_flag  in transaction_operations.cheque_production_flag%type,
                                          p_receipt_production_flag  in transaction_operations.receipt_production_flag%type,
                                          p_update_allowed_flag  in transaction_operations.update_allowed_flag%type)
   is
   begin
      insert into oms_owner.transaction_operations
         (module_name, txn_type, txn_operation_seq, dr_account_code, cr_account_code, 
          invalid_accounts_flag, cheque_production_flag, receipt_production_flag, update_allowed_flag, 
          list_seq, caseload_id, modify_date)
      select p_module_name, p_txn_type, 1, p_dr_account_code, p_cr_account_code, 
             p_invalid_accounts_flag, p_cheque_production_flag, p_receipt_production_flag, p_update_allowed_flag, 
             99, p_caseload_id, trunc(sysdate)
        from dual
       where not exists (select null
                           from oms_owner.transaction_operations
                          where caseload_id = p_caseload_id
                            and module_name = p_module_name
                            and txn_type = p_txn_type);
   end insert_transaction_operation;

begin
   for prison_rec in (select agy_loc_id
                        from agency_locations
                       where agency_location_type = 'INST'
                         and active_flag = 'Y'
                         and agy_loc_id not in ('OUT','TRN'))
   loop

      insert_transaction_operation(p_module_name => 'NOMISAPI', 
                                   p_caseload_id  => prison_rec.agy_loc_id,
                                   p_txn_type => 'HOA',  
                                   p_dr_account_code => 2101, 
                                   p_cr_account_code  => 2199, 
                                   p_invalid_accounts_flag  => 'N', 
                                   p_cheque_production_flag  => 'N', 
                                   p_receipt_production_flag  => 'N', 
                                   p_update_allowed_flag  => 'Y');  

      insert_transaction_operation(p_module_name => 'NOMISAPI', 
                                   p_caseload_id  => prison_rec.agy_loc_id,
                                   p_txn_type => 'HOR',  
                                   p_dr_account_code => 2199, 
                                   p_cr_account_code  => 2101, 
                                   p_invalid_accounts_flag  => 'N', 
                                   p_cheque_production_flag  => 'N', 
                                   p_receipt_production_flag  => 'N', 
                                   p_update_allowed_flag  => 'Y');  


   end loop;
end;
/
commit;
