insert into oms_owner.reference_codes (domain,
                                       code,
                                       description,
                                       list_seq,
                                       active_flag,
                                       system_data_flag)
   select 'PROFILE_TYPE',
          'NOMISAPI',
          'Nomis API',
          99,
          'Y',
          'Y'
     from dual
    where not exists
             (select 1
                from oms_owner.reference_codes
               where domain = 'PROFILE_TYPE' and code = 'NOMISAPI');

