insert into oms_owner.system_profiles (profile_type,
                                       profile_code,
                                       description,
                                       profile_value)
   select 'NOMISAPI',
          'EVENT_LIFE',
          'Number of days events are retained on the API_OFFENDER_EVENTS table',
          '30'
     from dual
    where not exists
             (select 1
                from oms_owner.system_profiles
               where profile_type = 'NOMISAPI' and profile_code = 'EVENT_LIFE');
