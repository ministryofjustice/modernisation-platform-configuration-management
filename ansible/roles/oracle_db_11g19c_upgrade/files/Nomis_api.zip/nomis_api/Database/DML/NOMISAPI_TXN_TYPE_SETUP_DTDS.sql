SET SERVEROUTPUT ON SIZE 1000000

DECLARE
   --
   -- Sets up all the transaction types that can be posted via the Nomis API for all prisons
   -- These transaction types are:
   --    DTDS
   --

   PROCEDURE insert_transaction_type (
      p_transaction_type   IN transaction_types.txn_type%TYPE,
      p_description        IN transaction_types.description%TYPE,
      p_txn_usage          IN transaction_types.txn_usage%TYPE,
      p_list_seq           IN transaction_types.list_seq%TYPE,
      p_caseload_type      IN transaction_types.caseload_type%TYPE)
   IS
   BEGIN
      SAVEPOINT s1;
      DBMS_OUTPUT.put_line (
         'Inserting transaction type ' || p_transaction_type);

      INSERT INTO transaction_types (TXN_TYPE,
                                     DESCRIPTION,
                                     TXN_USAGE,
                                     modify_date,
                                     LIST_SEQ,
                                     CASELOAD_TYPE)
         SELECT p_transaction_type,
                p_description,
                p_txn_usage,
                SYSDATE,
                p_list_seq,
                p_caseload_type
           FROM DUAL a
          WHERE NOT EXISTS
                   (SELECT 1
                      FROM transaction_types a
                     WHERE txn_type = p_transaction_type);

      DBMS_OUTPUT.put_line (SQL%ROWCOUNT || ' row(s) inserted.');
      DBMS_OUTPUT.put_line ('---------------------------------');
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK TO s1;
         DBMS_OUTPUT.put_line ('0 row inserted.');
         DBMS_OUTPUT.put_line (
            'An error occured processing: ' || p_transaction_type);
         DBMS_OUTPUT.put_line (
            SQLERRM || CHR (10) || DBMS_UTILITY.format_error_backtrace);
   END insert_transaction_type;

   PROCEDURE insert_transaction_operation (
      p_module_name               IN transaction_operations.module_name%TYPE,
      p_caseload_id               IN transaction_operations.caseload_id%TYPE,
      p_txn_type                  IN transaction_operations.txn_type%TYPE,
      p_dr_account_code           IN transaction_operations.dr_account_code%TYPE,
      p_cr_account_code           IN transaction_operations.cr_account_code%TYPE,
      p_invalid_accounts_flag     IN transaction_operations.invalid_accounts_flag%TYPE,
      p_cheque_production_flag    IN transaction_operations.cheque_production_flag%TYPE,
      p_receipt_production_flag   IN transaction_operations.receipt_production_flag%TYPE,
      p_update_allowed_flag       IN transaction_operations.update_allowed_flag%TYPE)
   IS
   BEGIN
   SAVEPOINT s1;
    DBMS_OUTPUT.put_line (
         'Inserting transaction operation ' || p_txn_type);           

         INSERT INTO oms_owner.transaction_operations (module_name,
                                                    txn_type,
                                                    txn_operation_seq,
                                                    dr_account_code,
                                                    cr_account_code,
                                                    invalid_accounts_flag,
                                                    cheque_production_flag,
                                                    receipt_production_flag,
                                                    update_allowed_flag,
                                                    list_seq,
                                                    caseload_id,
                                                    modify_date)
         SELECT p_module_name,
                p_txn_type,
                1,
                p_dr_account_code,
                p_cr_account_code,
                p_invalid_accounts_flag,
                p_cheque_production_flag,
                p_receipt_production_flag,
                p_update_allowed_flag,
                99,
                p_caseload_id,
                TRUNC (SYSDATE)
           FROM DUAL
          WHERE NOT EXISTS
                       (SELECT NULL
                          FROM oms_owner.transaction_operations
                         WHERE     caseload_id = p_caseload_id
                               AND module_name = p_module_name
                               AND txn_type = p_txn_type);
   DBMS_OUTPUT.put_line (SQL%ROWCOUNT || ' row(s) inserted.');
      DBMS_OUTPUT.put_line ('---------------------------------');                            
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK TO s1;
         DBMS_OUTPUT.put_line ('0 row inserted.');
         DBMS_OUTPUT.put_line (
            'An error occured processing: ' || p_txn_type);
         DBMS_OUTPUT.put_line (
            SQLERRM || CHR (10) || DBMS_UTILITY.format_error_backtrace);                            
   END insert_transaction_operation;
BEGIN

   insert_transaction_type (
      p_transaction_type   => 'DTDS',
      p_description        => 'Disbursement through Digital service',
      p_txn_usage          => 'D',
      p_list_seq           => 1,
      p_caseload_type      => 'INST');


   FOR prison_rec
      IN (SELECT agy_loc_id
            FROM agency_locations
           WHERE     agency_location_type = 'INST'
                 AND active_flag = 'Y'
                 AND agy_loc_id NOT IN ('OUT', 'TRN'))
   LOOP
      insert_transaction_operation (p_module_name               => 'NOMISAPI',
                                    p_caseload_id               => prison_rec.agy_loc_id,
                                    p_txn_type                  => 'DTDS',
                                    p_dr_account_code           => 2101,
                                    p_cr_account_code           => 1101,
                                    p_invalid_accounts_flag     => 'N',
                                    p_cheque_production_flag    => 'N',
                                    p_receipt_production_flag   => 'N',
                                    p_update_allowed_flag       => 'Y');
   END LOOP;

   COMMIT;
END;
/
