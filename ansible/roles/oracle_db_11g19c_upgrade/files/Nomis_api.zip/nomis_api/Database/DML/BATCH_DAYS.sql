set define off;
insert into oms_owner.reference_domains
   (domain, description, domain_status, owner_code, appln_code)
 values ('BATCH_DAY', 'Week day for batch digital jobs', 'ACTIVE', 'SYSCON', 'TAG');
insert into oms_owner.reference_codes
   (domain, code, description, list_seq, active_flag, system_data_flag)
 values ('BATCH_DAY', 'MON-FRI', 'Monday to Friday (5 days)', 8, 'N', 'Y');
insert into oms_owner.reference_codes
   (domain, code, description, list_seq, active_flag, system_data_flag)
 values ('BATCH_DAY', 'FRI', 'Friday', 5, 'Y', 'Y');
insert into oms_owner.reference_codes
   (domain, code, description, list_seq, active_flag, system_data_flag)
 values ('BATCH_DAY', 'MON', 'Monday', 1, 'Y', 'Y');
insert into oms_owner.reference_codes
   (domain, code, description, list_seq, active_flag, system_data_flag)
 values ('BATCH_DAY', 'SAT', 'Saturday', 6, 'Y', 'Y');
insert into oms_owner.reference_codes
   (domain, code, description, list_seq, active_flag, system_data_flag)
 values ('BATCH_DAY', 'SUN', 'Sunday', 7, 'Y', 'Y');
insert into oms_owner.reference_codes
   (domain, code, description, list_seq, active_flag, system_data_flag)
 values ('BATCH_DAY', 'THU', 'Thursday', 4, 'Y', 'Y');
insert into oms_owner.reference_codes
   (domain, code, description, list_seq, active_flag, system_data_flag)
 values ('BATCH_DAY', 'TUE', 'Tuesday', 2, 'Y', 'Y');
insert into OMS_OWNER.REFERENCE_CODES
   (domain, code, description, list_seq, active_flag, system_data_flag)
 values ('BATCH_DAY', 'WED', 'Wednesday', 3, 'Y', 'Y');
commit;
