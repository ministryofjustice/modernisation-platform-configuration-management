DECLARE
   --
   -- Creates a new txn_type MTDS and makes the incorrectly created
   -- MDTS txn_type inactive.
   -- 

   PROCEDURE insert_transaction_type (
      p_transaction_type   IN transaction_types.txn_type%TYPE,
      p_description        IN transaction_types.description%TYPE,
      p_txn_usage          IN transaction_types.txn_usage%TYPE,
      p_list_seq           IN transaction_types.list_seq%TYPE,
      p_caseload_type      IN transaction_types.caseload_type%TYPE)
   IS
   BEGIN
      SAVEPOINT s1;
      DBMS_OUTPUT.put_line (
         'Inserting transaction type ' || p_transaction_type);

      INSERT INTO transaction_types (TXN_TYPE,
                                     DESCRIPTION,
                                     TXN_USAGE,
                                     modify_date,
                                     LIST_SEQ,
                                     CASELOAD_TYPE)
         SELECT p_transaction_type,
                p_description,
                p_txn_usage,
                SYSDATE,
                p_list_seq,
                p_caseload_type
           FROM DUAL a
          WHERE NOT EXISTS
                   (SELECT 1
                      FROM transaction_types a
                     WHERE txn_type = p_transaction_type);

      DBMS_OUTPUT.put_line (SQL%ROWCOUNT || ' row(s) inserted.');
      DBMS_OUTPUT.put_line ('---------------------------------');
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK TO s1;
         DBMS_OUTPUT.put_line ('0 row inserted.');
         DBMS_OUTPUT.put_line (
            'An error occured processing: ' || p_transaction_type);
         DBMS_OUTPUT.put_line (
            SQLERRM || CHR (10) || DBMS_UTILITY.format_error_backtrace);
   END insert_transaction_type;

BEGIN

   insert_transaction_type (
      p_transaction_type   => 'MTDS',
      p_description        => 'Money through digital service',
      p_txn_usage          => 'R',
      p_list_seq           => 1,
      p_caseload_type      => 'INST');

   --
   -- Make the incorrectly entered MDTS txn_type inactive.
   --
   update transaction_types
      set active_flag = 'N'
    where txn_type = 'MDTS'
      and active_flag = 'Y';

   DBMS_OUTPUT.put_line (SQL%ROWCOUNT || ' row(s) updated.');
   DBMS_OUTPUT.put_line ('---------------------------------');


   COMMIT;
END;
/
