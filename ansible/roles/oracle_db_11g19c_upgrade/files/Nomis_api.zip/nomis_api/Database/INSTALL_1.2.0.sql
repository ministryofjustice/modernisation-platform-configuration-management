-- Run as sys or oms_owner
--
-- Install 3rd party packages pl/json
--
column curr_schema new_value prev_schema noprint
select user curr_schema from dual;
alter session set current_schema = api_owner;

PROMPT  Setting optimize level 
ALTER SESSION SET PLSQL_OPTIMIZE_LEVEL = 2;

/*
This software has been released under the MIT license:

  Copyright (c) 2010 Jonas Krogsboell inspired by code from Lewis R Cunningham

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.
*/
PROMPT -----------------------------------;
PROMPT -- Compiling objects for PL/JSON --;
PROMPT -----------------------------------;
@@pljson-master/uninstall.sql
@@pljson-master/src/json_value.typ
@@pljson-master/src/json_list.typ
@@pljson-master/src/json.typ
@@pljson-master/src/json_parser.sql
@@pljson-master/src/json_printer.sql
@@pljson-master/src/json_value_body.typ
@@pljson-master/src/json_ext.sql --extra helper functions
@@pljson-master/src/json_body.typ
@@pljson-master/src/json_list_body.typ
--@@src/grantsandsynonyms.sql --grants to core API
@@pljson-master/src/json_ac.sql --Wrapper to enhance autocompletion

PROMPT ------------------------------------------;
PROMPT -- Adding optional packages for PL/JSON --;
PROMPT ------------------------------------------;
@@pljson-master/src/addons/json_dyn.sql --dynamic sql execute 
@@pljson-master/src/addons/jsonml.sql --jsonml (xml to json)
@@pljson-master/src/addons/json_xml.sql --json to xml copied from http://www.json.org/java/org/json/XML.java
@@pljson-master/src/addons/json_util_pkg.sql --dynamic sql from http://ora-00001.blogspot.com/2010/02/ref-cursor-to-json.html
@@pljson-master/src/addons/json_helper.sql --Set operations on JSON and JSON_LIST
@@pljson-master/src/addons/pljson_table_impl.typ -- dynamic table from json document
@@pljson-master/src/addons/pljson_table_impl_body.typ -- dynamic table from json document

-- Change schema back to previous
set define on
alter session set current_schema = &prev_schema;
--
-- End of pl/json install
--

--
-- Tables and Sequences
--
@@Tables/NOMIS_API_LOGS.tab
@@Tables/LOG_ID.seq
@@Tables/API_OFFENDER_EVENTS.tab
@@Tables/API_EVENT_ID.seq

--
-- Grant privileges to apl_owner
--
@DDL/API_OWNER_GRANTS.sql

--
-- Compile Packages
--
@Packages/NOMIS_API_LOG.pkg
@Packages/CORE_UTILS.pkg
@Packages/JSON_BUILDER.pkg
@Packages/PSS_DATA_EXTRACTOR.pkg
@Packages/PSS_EVENTS.pkg
@Packages/API_FINANCE_PROCS.pkg
@Packages/API_OFFENDER_EVENT.pkg
@Packages/API_OFFENDER_PROCS.pkg
@Packages/API_PRISON_PROCS.pkg
@Packages/API_VISIT_PROCS.pkg
@Packages/NOMIS_API_BATCH.pkg

--
-- Grant privileges to apl_user and
-- create synonyms for api_owner packages
--
@DDL/API_USER_GRANTS.sql
@DDL/API_OWNER_SYNONYMS.sql

--
-- Create triggers in oms_owner
--

alter session set current_schema = oms_owner;

@@Triggers/OFFENDER_API_EVENT.trg
@@Triggers/OFF_ALERTS_API_EVENT.trg
@@Triggers/OFF_ASSESSMENTS_API_EVENT.trg
@@Triggers/OFF_BOOKINGS_API_EVENT.trg
@@Triggers/OFF_CASE_OFFICER_API_EVENT.trg
@@Triggers/OFF_EXT_MOV_API_EVENT.trg
@@Triggers/OFF_IEP_LEVEL_API_EVENT.trg
@@Triggers/OFF_IMPRISON_STS_API_EVENT.trg
@@Triggers/OFF_LANGUAGE_API_EVENT.trg
@@Triggers/OFF_OIC_SANCTION_API_EVENT.trg
@@Triggers/OFF_PROF_DETAILS_API_EVENT.trg

-- Change schema back to previous
set define on
alter session set current_schema = &prev_schema;
