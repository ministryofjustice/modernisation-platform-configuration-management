-- Run as sys or oms_owner

--
-- Grant privileges to apl_owner
--
@DDL/API_OWNER_GRANTS.sql

--
-- Compile Packages
--
@Packages/JSON_BUILDER.pkg
@Packages/PSS_DATA_EXTRACTOR.pkg
@Packages/PSS_EVENTS.pkg
@Packages/API_FINANCE_PROCS.pkg
@Packages/API_OFFENDER_PROCS.pkg
@Packages/API_BOOKING_PROCS.pkg
@Packages/API_LEGAL_PROCS.pkg

--
-- Grant privileges to apl_user and
-- create synonyms for api_owner packages
--
@DDL/API_USER_GRANTS_NEW.sql
@DDL/API_OWNER_SYNONYMS.sql

--
-- Create/replace triggers in oms_owner
--

column curr_schema new_value prev_schema noprint
select user curr_schema from dual;
alter session set current_schema = oms_owner;

@@Triggers/OFFENDER_API_EVENT.trg
@@Triggers/OFF_ALERTS_API_EVENT.trg
@@Triggers/OFF_ASSESSMENTS_API_EVENT.trg
@@Triggers/OFF_BOOKINGS_API_EVENT.trg
@@Triggers/OFF_CASE_OFFICER_API_EVENT.trg
@@Triggers/OFF_EXT_MOV_API_EVENT.trg
@@Triggers/OFF_IEP_LEVEL_API_EVENT.trg
@@Triggers/OFF_IMPRISON_STS_API_EVENT.trg
@@Triggers/OFF_LANGUAGE_API_EVENT.trg
@@Triggers/OFF_OIC_SANCTION_API_EVENT.trg
@@Triggers/OFF_PROF_DETAILS_API_EVENT.trg

-- Change schema back to previous
set define on
alter session set current_schema = &prev_schema;
